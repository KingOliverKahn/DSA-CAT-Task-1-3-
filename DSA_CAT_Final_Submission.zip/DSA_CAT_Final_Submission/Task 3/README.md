# Task 3: Factorial Using Forward and Backward Stacks

This project implements the factorial problem in Task 3 using a stack. It calculates factorial values in the forward direction and then uses LIFO behaviour to retrieve the stored values in the backward direction.

## What the program demonstrates

The forward calculation follows the recurrence:

1! = 1
2! = 1! x 2
3! = 2! x 3
...
n! = (n-1)! x n

Each calculated factorial is pushed onto a stack. The backward operation pops the values from the stack, so the results are obtained from n! down to 1!.

The implementation also checks for invalid negative input and unsigned long long overflow instead of silently producing an incorrect result.

## Build and run

Requirements: C++17 and CMake 3.16 or newer.

```text
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
./build/factorial_stack
```

On Windows, the executable is normally under `build/Debug/factorial_stack.exe` or the corresponding configuration directory.

## Example

For input 5 the program produces:

Forward factorial calculation
1! = 1
2! = 2
3! = 6
4! = 24
5! = 120

Backward stack calculation
5! = 120
4! = 24
3! = 6
2! = 2
1! = 1

## Project structure

`src/stack.h` and `src/stack.cpp` contain the stack implementation.

`src/factorial.h` and `src/factorial.cpp` contain the factorial algorithms and overflow checking.

`src/main.cpp` controls the program and displays the results.

`tests/test_main.cpp` checks stack operations, forward factorial calculation, backward retrieval, zero factorial and overflow handling.
